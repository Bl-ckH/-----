const Discord = require('discord.js');

const config = require('../config.json');

module.exports = {
  name: 'idee',
  description: 'Sage etwas durch den Bot',
  execute(message, args) {
    const sayMessage = args.join(' '); // Füge alle Argumente zu einer Nachricht zusammen

    if (!sayMessage) {
      message.reply('du musst eine Nachricht angeben.'); // Sende eine Fehlermeldung, wenn keine Nachricht angegeben wurde
      return;
    }

    message.delete(); // Lösche die ursprüngliche Nachricht des Benutzers

    const embed = new Discord.MessageEmbed()
      .setDescription(sayMessage)
      .setColor('#0099ff')
     
    message.channel.send({ embeds: [embed] }) // Sende das Embed in den Kanal
      .then(sentMessage => {
        sentMessage.react(config.emoji1); // Füge ein Daumen-hoch-Emoji als Reaktion hinzu
        sentMessage.react(config.emoji2); // Füge ein Daumen-runter-Emoji als Reaktion hinzu
      })
      .catch(error => console.error(error)); // Wenn ein Fehler auftritt, gib ihn in der Konsole aus
  },
};